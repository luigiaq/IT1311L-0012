package com.uap.it1311l.registrationapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
